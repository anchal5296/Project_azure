<?php include "header.php";
        require_once("dbconnect.php"); 

    if(isset($_POST['register'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $contact = $_POST['contact'];
        $password = $_POST['password'];
        $cpassword = $_POST['cpassword'];
        $date = date("Y-m-d");

        if ($password !== $cpassword) {
              echo "Password didn't Matched";
        }


         $insert_query =  mysqli_query($conn,"insert into userdetails(username, email, contact, password, createddate, status ) VALUES ('$username','$email','$contact','$password','$date',1)");

         if ($insert_query) {
            
            echo "
                <script>
                    alert('Registraton Successful');
                    window.location.href='home.php';
                </script>
            ";
            exit();
         }else{
            echo "
                <script>
                    alert('Please Input Proper Credentials');
                    window.location.href='Signup.php';
                </script>
            ";
         }

    }

 ?>



    <div class="logcontainer">
        <form class="login-12" method="post" action="" style="margin-top: 40px;">
            <span class="loghead" id="loghead" style="padding-left: 88px; font-size: 25;"><b  style="font-size: 25px;">Signup</b></span><hr><br><br>
            <label for="loginname">Name : </label> <input type="text" name="username" id="loginname" placeholder="Name" required style="height: 25px;border: outset;"><br><br>
            <label for="emaillog">Email: <input type="email" name="email" id="emaillog" placeholder="Email" required style="height: 25px;border: outset;"></label><br><br>
             <label for="contact">Contact : </label><input type="text" name="contact" id="contact" placeholder="contact" required style="height: 25px;border: outset;"><br><br>
              
            <label for="password">Create Password : </label><input type="password" name="password" id="password" placeholder="**********"
                    required style="height: 25px;border: outset;"><br><br>
            <label for="password">Confirm Password : </label><input type="password"  name="cpassword" id="password" placeholder="**********"
                    required style="height: 25px;border: outset;"><br><br> 
            <button type="submit" name="register" class="btn" style="color: white;
    width: 315px;
    height: 37px;
    border-radius: 20px;
    background-color: #6caf67;">Login</button><br><br>
            <hr style="color: black;"><br>
            Already have an Account <a href="newlogin.php" id="signup-now">Login Now</a>

        </form>
    </div>
<?php include "footer.php" ?>