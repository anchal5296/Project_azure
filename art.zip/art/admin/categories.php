<?php include "header.inc.php";?>
<?php 

$query = mysqli_query($conn,"select * from categories");


if(isset($_GET['type']) && $_GET['type']!='') { 
    $type=get_safe_value($conn,$_GET['type']);
    if ($type=='status') {
        $operation=get_safe_value($conn,$_GET['operation']);
        $id=get_safe_value($conn,$_GET['cid']);
        if ($operation=='active') {
            $status='1';
        }else{
            $status='0';
        }

        $status_update =  mysqli_query($conn,"update categories set is_active='$status' where cid='$id'");
        if ($status_update) {
            echo "
            <script>
            alert('Your Data has been updated Successfully');
            window.location.href='categories.php';
            </script>";
        }
    }

    if ($type=='delete') {
        $id=get_safe_value($conn,$_GET['cid']);
        $delete_cat = mysqli_query($conn,"delete from categories where cid='$id'");
        if ($delete_cat) {
            echo "
            <script>
            alert('Your Data has been Deleted Successfully');
            window.location.href='categories.php';
            </script>";

        }
    }
}
?>


<a href="manage_categories.php" style="color: white;
    background: #0eeb8f;
    margin: 36px;
    padding: 6px;
    padding-bottom: 11px; 
    text-decoration: none">Add Category</a>


<table style="border-collapse: inherit;
    height: 230px;
    width: 95%;
    margin-left: 35px; margin-top: 15px;">
    
    <thead style="background: black; color: white;">
        <tr>
            <th>C. No</th>
            <th>Categories Name</th>
            <th>Created Date</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody style="background: #f3c4b9;
    font-size: large;">
        <?php while ($row = mysqli_fetch_assoc($query)) {   ?>

            <tr>
                <td><?php echo $row['cid']; ?></td>
                <td><?php echo $row['cname']; ?></td>
                <td><?php echo $row['created_date']; ?></td>
                <td style="text-align: center;">
                    <?php
                    


                    echo "&nbsp;<a  style='color: white;
    background: red;
    padding: 9px 19px;
    border-radius: 19px;
    font-size: 18px;
    line-height: 3;
    text-decoration: none' href='?type=delete&cid=".$row['cid']."'>Delete</a>&nbsp;";
                   

                    ?>
                </td>
            </tr>
        <?php } ?>


    </tbody>
</table>
