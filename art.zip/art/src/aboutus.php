<?php include "header.php" ?>
<div style="padding-top: 20px;"><nav id="Aboutusnav">
        <h1">AboutUs</h1>

    </nav></div>


    <div class="myself" id="myself">
        <div class="myimg-1aboutus" style="padding: 10px;
    width: 320px;
    background-color: #f3ebeb;
    height: 300px;
    border-radius: 0px;">
            <img src="../images/virat.jpg" style="width: 300px;">
        </div>
        <div class="para-aboutus-1" style=" padding-left: 100px; padding-top: 20px;">
            <p style="font-family: cursive;
    background-color: #d4d0db;
    padding-left: 40px;
    padding-top: 30px;
    padding-right: 40px;
    text-align: justify;
    box-shadow: 5px 5px #c5bbbb;">

            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            




            </p>
        </div>
    </div>

    <div class="" id="myself">
        <div class="para-aboutus-1" style="    padding-right: 41px;">
            <p style="font-family: cursive;
    background-color: #d4d0db;
    padding-left: 40px;
    padding-right: 40px;
    text-align: justify;
    box-shadow: 5px 10px #c5bbbb;">


 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
             Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum

            </p>
        </div>
        <div class="myimg-1aboutus">
            <img src="../images/MSD.jpg" alt="" style="height: 400px; width: 570px;border-radius: 35px;">
        </div>
    </div>

     <?php include "footer.php" ?>