<?php 
    require_once "dbconnect.php";

    if(isset($_POST['login'])){
        $admin = $_POST['admin'];
        $password = $_POST['password'];

        $loginquery = mysqli_query($conn,"select * from admin_page where admin='$admin' and password='$password'");
       $fetchrows = mysqli_num_rows($loginquery);

        if($fetchrows > 0){
             $_SESSION['user_data'] =$admin; 
            $_SESSION['user_login']='yes';
            echo "<script>
                    alert('Login Successful');
                    window.location.href='ground.php';
                </script>";
        }else{
            echo "
            <script>
                    alert('Login Failed');
                    window.location.href='login_page.PHP';
                </script>";
        }

    }
 ?>
 
   <body style="padding-left: 337px;
    padding-right: 336px;">
    <div class="logcontainer" style="    padding-top: 25px;
    padding-left: 40px;
    margin: auto;
    margin-top: 145px;
    background: radial-gradient(#dedeeb, #eaeaef);
    height: 355px;
    width: 309px;
    border-radius: 0px;
    font-size: larger;
    box-shadow: 5px 5px #cfcccd;">

        <form class="login-12" action="" method="post">
            <span class="loghead" id="loghead" style="padding-left: 88px;"><b style="padding-left: 23px;">Login</span><hr><br>

            <label for="admin" style="font-size: initial;">Admin ID : </label>
            <input type="text" id="admin" name="admin" placeholder="Admin ID" required
                style="border-radius: 8px;"><br><br>

            <label for="Password" style="font-size: initial;">Password :  </label>
            <input type="password" name="password" id="password" placeholder="**********" required style="border-radius: 8px
            ;"><br><br>
            <input type="checkbox"><label style="font-size: initial;">Remember Me </label><br><br>
            <button type="submit" name="login" class="btn" style="color: white;
    width: 270px;
    height: 37px;
    font-size: 14px;
    font-weight: bold;
    background-color: #5474cf;
    border-radius: 31px;">Login</button><br><br>
            <a href="" id="login-forgetpass" style="text-decoration: none;
    font-size: initial;
    padding-left: 150px;">Forget password?</a><br><hr>
          <label style="font-size: initial;">  Not a member? </label> <a href="Signup.php" id="signup-now" style="text-decoration: none; font-size: initial;">Signup Now</a>

        </form>
    </div>
</body>