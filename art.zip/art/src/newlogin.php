<?php 
    include "header.php";
    require_once "dbconnect.php";

    if(isset($_POST['login'])){
        $email = $_POST['email'];
        $password = $_POST['password'];


        $loginquery = mysqli_query($conn,"select * from userdetails where email='$email' and password='$password'");
       $fetchrows = mysqli_num_rows($loginquery);

        if($fetchrows > 0){
             $_SESSION['user_data'] =$email; 
            $_SESSION['user_login']='yes';
            echo "<script>
                    alert('Login Successful');
                    window.location.href='home.PHP';
                </script>";
        }else{
            echo "
            <script>
                    alert('Login Failed');
                    window.location.href='newlogin.PHP';
                </script>";
        }
    }
 ?>


    <div class="logcontainer">
        <form class="login-12" action="" method="post" style="margin-top: 15px;">
            <span class="loghead" id="loghead" style="padding-left: 125px;"><b style="font-size: 25px;">Login</span><br><hr><br>

            <div style="font-size: initial;">
            <label for="email">Email : </label>
            <input type="email" id="emaillog" name="email" placeholder="Email" required style="height: 25px;border: outset;"><br><br>

            <label for="Password">Password : </label> 
            <input type="password"  name="password" id="password" placeholder="**********" required style="height: 25px;border: outset;"><br><br>
            Remember Me <input type="checkbox"><br><br>
            <a href="" id="login-forgetpass">Forget password?</a><br><br>

            <button type="submit" name="login" class="btn" style="width: 310px;
    height: 37px;
    border-radius: 18px;
    color: white;
    background-color: #6caf67;">Login</button><br><br>
            Not a mamber? <a href="Signup.php" id="signup-now">Signup Now</a>

            </div>


        </form>
    </div>
<?php include "footer.php" ?>