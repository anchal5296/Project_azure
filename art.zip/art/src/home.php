<?php include "header.php";
require "function.php";
require_once("dbconnect.php");
$categories_arr = array();
$categories_result = mysqli_query($conn,"select * from categories where is_active=1");
// echo mysqli_num_rows($categories_result);
while ($row =  mysqli_fetch_assoc($categories_result)) {
        $categories_arr[] = $row;
}


  
   

$get_product=get_product($conn,'','','');




 ?>

         <div class="small-container">

    <li class="dropdown"><i class="fa fa-user"></i>
                <div class="dropdown-title">Categories</div>
                <div class="dropdown-content">
                    <!-- Categories Dropdown -->
                  <?php foreach ($categories_arr as $list) { ?>
                     <a href="categories.php?cid=<?php echo $list['cid']; ?>"><?php echo $list['cname']; ?></a>
               <?php   } ?>
              </div>
            </li>

            
            <div class="row">
                <?php foreach($get_product as $row){ ?>
                <div class="col-4">
                    <a href="singleProduct.php?pid=<?php echo $row['pid']; ?>"> <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image']; ?>" alt="">
                    </a>
                    <h4><?php echo $row['product_name']; ?></h4>
                    <p><b>Price-:</b> &#8377;<?php echo $row['price']; ?></p>
                </div>
            <?php } ?>
               
            </div>



           

       <?php include "footer.php" ?>