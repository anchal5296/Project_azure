<?php include "header.inc.php";


$users_query = mysqli_query($conn,"select * from userdetails");



?>




<table style="border-collapse: inherit;
    height: 230px;
    width: 95%;
    margin-left: 35px;">
	<thead style="background: black; color: white;">
		<tr>
			<th>Sr. No</th>
			<th>Username</th>
			<th>EMail</th>
			<th>Password</th>
			<th>Created Date</th>
		</tr>
	</thead>
	<tbody style="background: #ede6b2;
    font-size: large;">
		<?php while ($row= mysqli_fetch_assoc($users_query)) { ?>
		<tr>
			<td><?php echo $row['id']; ?></td>
			<td><?php echo $row['username']; ?></td>
			<td><?php echo $row['email']; ?></td>
			<td><?php echo $row['password']; ?></td>
			<td><?php echo $row['createddate']; ?></td>
		</tr>
			<?php } ?>
	</tbody>
</table>