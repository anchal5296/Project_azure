<?php 
require 'dbconnect.php';
session_destroy();

				echo "<script>
                    alert('Logout');
                    window.location.href='newlogin.PHP';
                </script>";
?>