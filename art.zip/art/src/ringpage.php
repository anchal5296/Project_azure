<?php include "header.php" ?>

        <div class="small-container">
            <h1 class="title" id="title-1">All-Products <select id="shortby-1">
                    <option value="">Defaul Shorting</option>
                    <option value="">Short by Price</option>
                    <option value="">Short by Ratting</option>
                    <option value="">Short by Popularity</option>
                    <option value="">Short by Sale</option>
                </select>

            <select id="shortby-1">
                     <option value="">All Product</option>
                    <option value=""><a href="">Ring</a> </option>
                    <option value=""><a href="">Naklesh</a> </option>
                    <option value=""><a href="">Mangalsutra</a> </option>
                    <option value=""><a href="">Bracelet</a> </option>
                    <option value=""><a href="">Nose Ring</a> </option>
                </select>

                <hr>
            </h1>
            <div class="row">
                <div class="col-4">
                    <a href="singleProfuct.php"> <img src="../images/28689382e8bb61c53a56bbed4b5f7d90.jpg" alt="">
                    </a>
                    <h4>GoldenChain</h4>
                    <p>&#8377;3100</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/earing.jpg" alt=""> </a>
                    <h4>Earing</h4>
                    <p>&#8377;2270</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/nekless.jpg" alt=""> </a>
                    <h4>nekless</h4>
                    <p>&#8377;4150</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/neklesss.jpg" alt=""> </a>
                    <h4>goldnekless</h4>
                    <p>&#8377;3150</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/jewellery.jpg" alt=""> </a>
                    <h4>jewelleri</h4>
                    <p>&#8377;1140</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/jewlwrry-2.jpg" alt=""> </a>
                    <h4>jewellery-2</h4>
                    <p>&#8377;3500</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/bracelet-1.jpg" alt=""> </a>
                    <h4>bracelet-1</h4>
                    <p>&#8377;4120</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/mangalsutra-2.jpg" alt=""> </a>
                    <h4>mangalsutra-2</h4>
                    <p>&#8377;2170</p>
                </div>
            </div>
            <div class="row">
                <div class="col-4">
                    <a href=""> <img src="../images/mixjewelerry.jpg" alt=""> </a>
                    <h4>mixjewelerry</h4>
                    <p>&#8377;3510</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/mangalsutra-1.jpg" alt=""> </a>
                    <h4>mangalsutra-1</h4>
                    <p>&#8377;2750</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/braclet-1.jpg" alt=""> </a>
                    <h4>bracelet-1</h4>
                    <p>&#8377;2350</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/earing-1.jpg" alt=""> </a>
                    <h4>earing-1</h4>
                    <p>&#8377;1150</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/../images/../images/../images/blacknekless.jpg" alt=""> </a>
                    <h4>blacknekless</h4>
                    <p>&#8377;2120</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/../images/../images/neklesss.jpg" alt=""> </a>
                    <h4>nekless</h4>
                    <p>&#8377;3120</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/../images/jewellery.jpg" alt=""> </a>
                    <h4>jewellery</h4>
                    <p>&#8377;2150</p>
                </div>
                <div class="col-4">
                    <a href=""> <img src="../images/51eAT4eA+1L._UY500_.jpg" alt=""> </a>
                    <h4>WeddingRing</h4>
                    <p>&#8377;1750</p>
                </div>
            </div>
        </div>
        <div class="pagebnt">
            <span>1</span>
            <span>2</span>
            <span>3</span>
            <span>4</span>
            <span>&#8594</span>

        </div>

       <?php include "footer.php" ?>