<?php include "header.php";
   
    require_once "dbconnect.php";

    if(isset($_POST['commentsend'])){
    	 $name = $_POST['name'];
         $email = $_POST['email'];
         $contact_no = $_POST['number'];
         $comment = $_POST['comment'];
         $date = date("Y-m-d");

      $insert_query = mysqli_query($conn,"insert into contact(name,email,contact_no,comment,createddate) VALUES('$name','$email','$contact_no','$comment','$date')");

	if ($insert_query) {
		header('location: contact.php');
		die();
	}

   }


 ?>




<h1 style="text-align: center;">Contact Us</h1>

<form method="post" action="">
	<div class="comment-1" style="padding-top: 25px;
    padding-left: 40px;
    margin: auto;
    margin-top: 40px;
    background-color: #f6f7f9;
    height: 400px;
    width: 533px;
    border-radius: 30px;
    font-size: larger;">
		<input type="text" name="name" placeholder="Your Name" required style="height: 50px; width: 230px;">
	<input type="email" name="email" placeholder="Your Email" required style="height: 50px; width: 230px;"><br><br><br>
	<input type="number" name="number" placeholder="Your Phone No" required style="height: 50px; width: 230px;">
    <input type="text" name="subject" placeholder="Subject" required style="height: 50px; width: 230px;">
	<textarea type="text" name="comment" placeholder="Your Message Here..!!" required style="width: 95%;
  height: 150px;
  padding: 12px 20px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  background-color: white;
  font-size: 16px;
  margin-top: 10px;"></textarea>
	<input type="submit" name="commentsend" style="    height: 35px;
    background-color: #afafe1;
    width: 100px;
    color: white;
    font-size: large;
    font-weight: bold;">
	</div>
</form>

