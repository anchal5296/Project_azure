<?php include "header.inc.php";?>

<?php

$query = mysqli_query($conn,"select * from contact");
?>





<table style="border-collapse: inherit;
    height: 230px;
    width: 95%;
    margin-left: 35px;">
    <thead style="    background: black; color: white;">
    	<tr>
        	<th>u. No</th>
        	<th>Name</th>
        	<th>Contact_no</th>
        	<th>Email</th>
        	<th>Comment</th>
        	<th>createddate</th>
    	</tr>
    </thead>

   	<tbody style="background: #bfe5f1;
    font-size: large;">
   		<?php while ($row = mysqli_fetch_assoc($query)) {   ?>

		 <tr>
		        <td><?php echo $row['id']; ?></td>
		        <td><?php echo $row['name']; ?></td>
		        <td><?php echo $row['contact_no']; ?></td>
		        <td><?php echo $row['email']; ?></td>
		        <td><?php echo $row['comment']; ?></td>
		        <td><?php echo $row['createddate']; ?></td>
		    </tr> 
		<?php } ?>
	</tbody>
</table>