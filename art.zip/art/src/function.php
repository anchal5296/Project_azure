<?php

function get_safe_value($conn,$str)
	{
	if($str!='') {
		$str=trim($str);
		return mysqli_real_escape_string($conn,$str);
					}
		}




	
function get_product($conn,$limit='',$cat_id='',$product_id='') {
	$sql="select * from product where is_active=1";
	
	if($cat_id!=''){
		$sql.=" and cid=$cat_id";
	}
	
	if($product_id!=''){
		$sql.=" and pid=$product_id";
	}
	$sql.=" order by pid desc";
	
	if($limit!=''){
		$sql.=" limit $limit ";
	}

	$res=mysqli_query($conn,$sql);
	$data=array(); 
	while($row=mysqli_fetch_assoc($res)){
		$data[]=$row;
	} 
	return $data;
}  



 ?>