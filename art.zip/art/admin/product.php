<?php include "header.inc.php"; ?>

<?php
$product_result = mysqli_query($conn,"select product.*,categories.cname from product,categories where product.cid = categories.cid order by product.pid desc");
//echo mysqli_num_rows($product_result);

if(isset($_GET['type']) && $_GET['type']!='') { 
    $type=get_safe_value($conn,$_GET['type']);
    if ($type=='status') {
        $operation=get_safe_value($conn,$_GET['operation']);
        $id=get_safe_value($conn,$_GET['pid']);
        if ($operation=='active') {
            $status='1';
        }else{
            $status='0';
        }

        $status_update =  mysqli_query($conn,"update product set is_active='$status' where pid='$id'");
        if ($status_update) {
            echo "
            <script>
            alert('Your Data has been updated Successfully');
            window.location.href='product.php';
            </script>";
        }
    }

    if ($type=='delete') {
        $id=get_safe_value($conn,$_GET['pid']);
        $delete_cat = mysqli_query($conn,"delete from product where pid='$id'");
        if ($delete_cat) {
            echo "
            <script>
            alert('Your Data has been Deleted Successfully');
            window.location.href='product.php';
            </script>";

        }
    }
}


?>

<a href="manage_product.php" class="btn btn-success">Add New</a>
<div class="container-fluid">
    <div class="table-responsive">
        <table class="table" style="border-collapse: initial;
    background: bisque;">
    <thead class="thead thead-dark">
        <tr>
            <th>SR No.</th>
            <th>Category</th>
            <th>Product Name</th>
            <th>Image</th>
            <th>Price</th>
            <th>Description</th>
            <th>Created Date</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = mysqli_fetch_assoc($product_result)) {   ?>
        <tr>
            <td><?php echo $row['pid']; ?></td>
            <td><?php echo $row['cname']; ?></td>
            <td><?php echo $row['product_name']; ?></td>
            <td ><img height="100" width="100" src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image']; ?>"></td>
            <td><?php echo $row['price']; ?></td>
            <td><?php echo $row['description']; ?></td>
            <td><?php echo $row['created_date']; ?></td>
             <td><?php
                   
                    echo "&nbsp;<a class='btn btn-danger' href='?type=delete&pid=".$row['pid']."'>Delete</a>&nbsp;";
                  
                    ?></td>
        </tr>
        <?php } ?>
    </tbody>
</table>
    </div>
</div>