<?php 
require 'dbconnect.php';
session_destroy();

				echo "<script>
                    alert('Logout');
                    window.location.href='login_page.PHP';
                </script>";
?>