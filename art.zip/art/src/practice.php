<?php 

// require 'dbconnect.php';

	
//  $loginquery = mysqli_query($conn,"select * from userdetails");
//  echo mysqli_num_row($loginquery);

//  	//Login Page
//   $_SESSION['user_data'] =$email; 
//    $_SESSION['user_login']='yes';


// //after require on all pages

// if(isset($_SESSION['user_login']) && $_SESSION['user_login']!=''){

// }else{
//   echo "<script>
//     window.location.href='login/login_page.php';
//   </script>";  
// }
//  


$row  = array("Deepak","DUbey");
echo $row[0];

?>