<?php



session_start();

$conn = mysqli_connect("localhost","root","","art");


if (!$conn) {
	echo "Connection Error";
}



define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/art/');
define('SITE_PATH','http://127.0.0.1/art');

define('PRODUCT_IMAGE_SERVER_PATH',SERVER_PATH.'/images/products/');
define('PRODUCT_IMAGE_SITE_PATH',SITE_PATH.'/images/products/');



?>