-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2023 at 10:57 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `art`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_cart`
--

CREATE TABLE `add_cart` (
  `id` int(11) NOT NULL,
  `pid` int(11) NOT NULL,
  `user_data` varchar(250) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `mrp` decimal(10,0) NOT NULL,
  `size` decimal(10,0) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `admin_page`
--

CREATE TABLE `admin_page` (
  `id` int(11) NOT NULL,
  `admin` varchar(25) NOT NULL,
  `password` varchar(20) NOT NULL,
  `createddate` date NOT NULL,
  `is_active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_page`
--

INSERT INTO `admin_page` (`id`, `admin`, `password`, `createddate`, `is_active`) VALUES
(1, 'admin', 'admin', '2023-01-18', 1),
(2, 'admin1', 'admin1', '0000-00-00', 1),
(3, 'admin2', 'admin2', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cid` int(11) NOT NULL,
  `cname` varchar(250) NOT NULL,
  `created_date` date NOT NULL,
  `is_active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cid`, `cname`, `created_date`, `is_active`) VALUES
(17, 'oil paints', '2023-04-04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `contact_no` bigint(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `createddate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `manage_order`
--

CREATE TABLE `manage_order` (
  `order_id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `phone_no` bigint(20) NOT NULL,
  `address` varchar(250) NOT NULL,
  `pay_mode` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `mrp` decimal(10,2) NOT NULL,
  `image` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `short_description` varchar(150) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_date` date NOT NULL,
  `is_active` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `cid`, `product_name`, `price`, `mrp`, `image`, `description`, `short_description`, `quantity`, `created_date`, `is_active`) VALUES
(71, 17, 'ganpati bappa', '12000.00', '0.00', '588_ganpati bappa.jpg', 'cadmium yellow alizarin crimson (good for still lifes, and man-made colors), or cadmium red dark (good for muted landscapes) ultramarine blue mars black titanium white', '', 0, '2023-04-04', 1),
(72, 17, 'Virat kohali', '1300.00', '0.00', '585_virat.jpg', 'cadmium yellow alizarin crimson (good for still lifes, and man-made colors), or cadmium red dark (good for muted landscapes) ultramarine blue mars black titanium white', '', 0, '2023-04-04', 1),
(73, 17, 'learoilpaint', '1100.00', '0.00', '826_learnoilpaintinglessonsonline.jpg', 'cadmium yellow alizarin crimson (good for still lifes, and man-made colors), or cadmium red dark (good for muted landscapes) ultramarine blue mars black titanium white', '', 0, '2023-04-04', 1),
(74, 17, 'lord Shiva', '1400.00', '0.00', '308_lord shiva oil painting.jpg', 'cadmium yellow alizarin crimson (good for still lifes, and man-made colors), or cadmium red dark (good for muted landscapes) ultramarine blue mars black titanium white', '', 0, '2023-04-04', 1),
(75, 17, 'MSD', '1200.00', '0.00', '479_msd.jpg', 'cadmium yellow alizarin crimson (good for still lifes, and man-made colors), or cadmium red dark (good for muted landscapes) ultramarine blue mars black titanium white', '', 0, '2023-04-04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(25) NOT NULL,
  `contact` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `createddate` date NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`id`, `username`, `email`, `contact`, `password`, `createddate`, `status`) VALUES
(1, 'Deepak', 'dubeyd2001@gmail.com', 9930894230, '123', '2023-01-16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users_order`
--

CREATE TABLE `users_order` (
  `order_id` int(250) NOT NULL,
  `pid` int(150) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users_order`
--

INSERT INTO `users_order` (`order_id`, `pid`, `product_name`, `price`, `quantity`) VALUES
(18, 70, 'Football', 1000, 1),
(19, 70, 'Football', 1000, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_cart`
--
ALTER TABLE `add_cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_page`
--
ALTER TABLE `admin_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manage_order`
--
ALTER TABLE `manage_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_cart`
--
ALTER TABLE `add_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin_page`
--
ALTER TABLE `admin_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `manage_order`
--
ALTER TABLE `manage_order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;

--
-- AUTO_INCREMENT for table `userdetails`
--
ALTER TABLE `userdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
