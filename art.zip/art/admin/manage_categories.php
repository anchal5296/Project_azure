<?php include "header.inc.php"; ?>

<?php
$categories='';
$date = date("Y-m-d");
$msg='';
if (isset($_GET['cid']) && $_GET['cid']!='') {
	$id = get_safe_value($conn,$_GET['cid']);
	$res = mysqli_query($conn,"select * from categories where cid='$id'");

	$check = mysqli_num_rows($res);
	if($check>0){
		$row = mysqli_fetch_assoc($res);
		$categories = $row['cname']; 
	}else{
		header('location:categories.php');
		die();
	}
}


if (isset($_POST['submit'])) 
{
	$categories=get_safe_value($conn,$_POST['categories']);

	$res=mysqli_query($conn,"select * from categories where cname='$categories'");
	$check=mysqli_num_rows($res);
	if($check>0)
	{
		if(isset($_GET['cid']) && $_GET['cid']!='') 
		{
			$getData=mysqli_fetch_assoc($res); 
			if($id==$getData['cid']){

			}
			else
			{
				$msg="This categories already exist..!!";
			}
		}
		else
		{
			$msg="This categories already exist..!!";
		}
	}

	if ($msg=='') {
		if(isset($_GET['cid']) && $_GET['cid']!='') {
			mysqli_query($conn,"update categories set cname='$categories',created_date='$date' where cid='$id'");
		}else{
			mysqli_query($conn,"insert into categories(cname,created_date,is_active) values('$categories','$date',1)");
		}
		header('location: categories.php');
		die();
	}

}  
?>

<form method="post" action="">
	<input type="text" name="categories" placeholder="Enter Category" value="<?php echo $categories; ?>">
	<?php echo $msg; ?>
	<input type="submit" name="submit">
</form>
