<?php 
require 'dbconnect.php';
require 'function.php';
if(isset($_SESSION['user_login']) && $_SESSION['user_login']!=''){

}else{
  echo "<script>
    window.location.href='login_page.php';
  </script>";  
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>home page</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/4.6.2/css/bootstrap.min.css" integrity="sha512-rt/SrQ4UNIaGfDyEXZtNcyWvQeOq0QLygHluFQcSjaGB04IxWhal71tKuzP6K8eYXYB6vJV4pHkXcmFGGQ1/0w==" crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>
    <div class="header">
        <div class="container">
            <div class="navbar">
                <nav>
                    <ul>
                        <li><a href="product.php">Products</a></li>
                        <li><a href="categories.php">Categories</a></li>
                        <li><a href="users_order.php">Booked</a></li>
                        <li><a href="users.php">Users</a></li>
                        <li><a href="admin_page.php">Admin</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>