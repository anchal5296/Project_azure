<?php include "header.inc.php"; 

$categoriers_data = mysqli_query($conn,"select * from categories");

$pname='';
$description='';
$price=''; 
$image = '';
$image_required = '';
$date = date("Y-m-d");
$msg='';
if (isset($_GET['pid']) && $_GET['pid']!='') {
	$id = get_safe_value($conn,$_GET['pid']);
	$res = mysqli_query($conn,"select * from product where pid='$id'");
	$check = mysqli_num_rows($res);
	if($check>0){
		$row = mysqli_fetch_assoc($res);
		$pname = $row['product_name']; 
		$image=$row['image'];
		$description = $row['description']; 
		$price = $row['price']; 
		$date = $row['date'];
	}else{
		header('location:product.php');
		die();
	}
}


if (isset($_POST['submit'])) 
{
	$pname=get_safe_value($conn,$_POST['pname']);
	$description=get_safe_value($conn,$_POST['description']);
	$category=get_safe_value($conn,$_POST['category']);
	$image=get_safe_value($conn,$_POST['image']);
	$price=get_safe_value($conn,$_POST['price']);

	$res=mysqli_query($conn,"select * from product where product_name='$pname' and mrp='$mrp'");
	$check=mysqli_num_rows($res);
	if($check>0)
	{
		if(isset($_GET['pid']) && $_GET['pid']!='') 
		{
			$getData=mysqli_fetch_assoc($res); 
			if($id==$getData['pid']){

			}
			else
			{
				$msg="This product already exist..!!";
			}
		}
		else
		{
			$msg="This product already exist..!!";
		}
	}

	if ($msg=='') {
		if(isset($_GET['pid']) && $_GET['pid']!='') {
			if ($_FILES['image']['name']!='') {
            $image=rand(111,999).'_'.$_FILES['image']['name'];
            move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);
			$update_sql = "update product set cid='$category',product_name='$pname',description='$description',short_description='$short_description',quantity='$qty',price='$price',mrp='$mrp',image='$image',created_date='$date' where pid='$id'";
			} else{
          $update_sql="update product set cid='$category',product_name='$pname',description='$description',short_description='$short_description',quantity='$qty',price='$price',mrp='$mrp',created_date='$date' where pid='$id'";
       }
       mysqli_query($conn,$update_sql);
		}else{

					      $image=rand(111,999).'_'.$_FILES['image']['name'];
      move_uploaded_file($_FILES['image']['tmp_name'],PRODUCT_IMAGE_SERVER_PATH.$image);


			mysqli_query($conn,"insert into product(cid,product_name,mrp,price,description,short_description,image,quantity,created_date,is_active) values('$category','$pname','$mrp','$price','$description','$short_description','$image','$qty','$date',1)");
		}
		header('location: product.php');
		die();
	}

}  




?>






<div class="container">
	<form class="form border p-5" action="" method="post" enctype="multipart/form-data">
    <select name="category" id="" class="form-control">
        <option value="">Select Categories</option>
        <?php while($row = mysqli_fetch_assoc($categoriers_data)){ ?>
        	
        <option value="<?php echo $row['cid']  ?>">
            <?php echo $row['cname'];  ?>
        </option>


        <?php      	} ?>
    </select>
    <input type="text" class="form-control" name="pname" id="" placeholder="Product Name" value="<?php echo $pname ?>">
    <input type="file" class="form-control" name="image" id="" value="<?php echo $image_required ?>" />
    <input type="text" class="form-control" name="description" id="" placeholder="Description" value="<?php echo $description ?>"/>
    <input type="text" class="form-control" name="price" id="" placeholder="Price" value="<?php echo $price ?>" />
    <input type="submit" class="btn btn-success" name="submit">
</form>
</div>
