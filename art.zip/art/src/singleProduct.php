<?php include "header.php";



include "function.php";
require_once("dbconnect.php");
$categories_arr = array();
$categories_result = mysqli_query($conn,"select * from categories where is_active=1");
// echo mysqli_num_rows($categories_result);
while ($row =  mysqli_fetch_assoc($categories_result)) {
        $categories_arr[] = $row;
}


   

$product_id=mysqli_real_escape_string($conn,$_GET['pid']);
if($product_id>0) { 
$get_product=get_product($conn,'','',$product_id);

 }else{
?>
<script>
    window.location.href = 'Product.php';
</script>
<?php 
 }


 ?>

<?php foreach($get_product as $row) { ?>

    <form action="managecart.php" method="post">
        
<div class="small-container">
    <div class="firstproduct-singleproduct">
                    
      <div class="singleProfuct-1">
            <div class="col-6-singleproduct-img">
                <img src="<?php echo PRODUCT_IMAGE_SITE_PATH.$row['image']; ?>" width="100%">
            </div>
        </div>

        <div class="product-information-1" style="    padding-top: 149px;
    padding-left: 81px;
    background-color: #a2bbd1;
    width: 536px;">
            <!-- <h4>Ho</h4><br> -->
            <h1><?php echo $row['product_name']; ?></h1>
            <p>Price:&#8377;<?php echo $row['price']; ?></p>

            <input type="hidden" value="<?php echo $row['pid']; ?>" name="pid" style="width: 40px;">
            <input type="hidden" value="<?php echo $row['product_name']; ?>" name="product_name" style="width: 40px;">
            <input type="hidden" value="<?php echo $row['price']; ?>" name="price" style="width: 40px;">
            <a href="add to cart.php" class="btn"><button class="addtobtn" name="addcart">Book Now</button></a>
            <h3 class="product-del">Details
            </h3>
            <p><?php echo $row['description']; ?> </p>
        </div>
    </div>

</div>

<?php } ?>

    </form>


       


<?php include "footer.php" ?>