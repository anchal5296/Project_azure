<?php include "header.inc.php"; ?>


                           <table class="table " style="background: burlywood;
    border-collapse: initial;">
                              <thead>
                                 <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                    <th>Payment Mode</th>
                                    <th>Booking</th>
                                 </tr>
                              </thead>

                              <tbody>
                                <?php  
                                $query="SELECT * FROM `manage_order`";
                                $user_result=mysqli_query($conn,$query);
                                while($row=mysqli_fetch_assoc($user_result))
                                {
                                 echo"
                                 <tr>
                                 <td>$row[order_id]</td>
                                 <td>$row[name]</td>
                                 <td>$row[phone_no]</td>
                                 <td>$row[address]</td>
                                 <td>$row[pay_mode]</td>
                                 <td>
                                 <table class='table text-center table-dark'>
                                 <thead>
                                 <tr>
                                 <th>Turf</th>
                                 <th>Price</th>
                                 <th>Hour</th>
                                 </tr>
                                 </thead>
                                 <tbody>
                                 ";

                                 $order_query="SELECT * FROM `users_order` WHERE order_id=$row[order_id]";
                                 $order_result=mysqli_query($conn,$order_query);
                                 while($order_fetch=mysqli_fetch_assoc($order_result))
                                 {
                                    echo
                                    "
                                    <tr>
                                    <td>$order_fetch[product_name]</td>
                                    <td>$order_fetch[price]</td>
                                    <td>$order_fetch[quantity]</td>
                                    </tr>
                                    ";
                                 }
                                 echo "
                                 </tbody>
                                 </table>
                                 </td>
                                 </tr> 
                                 ";
                              }
                              ?>

                           </tbody>

                        </table>