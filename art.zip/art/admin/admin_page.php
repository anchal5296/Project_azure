<?php include "header.inc.php";

$query = mysqli_query($conn,"select * from admin_page");
?>


<table style="border-collapse: inherit;
    height: 230px;
    width: 95%;
    margin-left: 35px;">
    <thead style="    background: black; color: white;">
    	<tr>
        	<th>Sr. No</th>
        	<th>Admin ID</th>
        	<th>Password</th>
        	<th>Created Date</th>
        	<th>Status</th>
    	</tr>
    </thead>

   	<tbody style="background: ;
    font-size: large;">
   		<?php while ($row = mysqli_fetch_assoc($query)) {   ?>

		 <tr>
		        <td><?php echo $row['id']; ?></td>
		        <td><?php echo $row['admin']; ?></td>
		        <td><?php echo $row['password']; ?></td>
		        <td><?php echo $row['createddate']; ?></td>
		        <td><?php echo $row['is_active']; ?></td>

		    </tr>
    <?php } ?>


   	</tbody>
</table>
	